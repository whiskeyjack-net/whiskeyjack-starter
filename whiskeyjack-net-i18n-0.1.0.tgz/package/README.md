# @whiskeyjack-net/i18n

The shared react-i18next bootstrap used by every Whiskeyjack app. One
`createI18n()` instead of copy-pasting the i18next init, so language detection,
the React binding, the `en` fallback, and `<html lang>`/`dir` (RTL) sync are
identical everywhere.

*This README documents the published artifact (`@whiskeyjack-net/i18n`, staged
via `npm run build:package`). Inside the monorepo the workspace source export is
`@whiskeyjack/i18n`.*

## Install

```bash
npm install @whiskeyjack-net/i18n
```

Requires `react` 18+ (peer). Ships `i18next`, `react-i18next`, and
`i18next-browser-languagedetector` as dependencies.

## Use

```ts
// src/i18n/index.ts
import { createI18n } from '@whiskeyjack-net/i18n'
import en from './locales/en.json'
import ar from './locales/ar.json'

export default createI18n({ en, ar })
```

```tsx
// main.tsx
import './i18n'
```

Components use `useTranslation()` from `react-i18next` as usual. Each locale is
wrapped in the default `translation` namespace; coverage varies per app (an
English-only app just passes `{ en }`).

## API

- **`createI18n(locales, options?)`** – configure and return the shared i18next
  instance. `locales` maps a language code to its translation object. On
  `languageChanged` it updates `<html lang>` and `<html dir>` (RTL for
  Arabic/Urdu/Farsi/Hebrew). `options.fallbackLng` defaults to `en`.
- **`activeLanguage(supported)`** – the active language normalized to one of
  `supported`, for binding a language picker to what is actually displayed
  (including the first-run system-detected language).

## License

MIT
