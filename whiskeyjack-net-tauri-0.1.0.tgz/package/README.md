# @whiskeyjack-net/tauri

The Tauri-native **app-shell layer** for the Whiskeyjack design system — the
window-chrome pieces the DS itself stays free of, so the design system runs
identically as a plain web app or inside a Tauri window.

*This README documents the published artifact (`@whiskeyjack-net/tauri`, staged
via `npm run build:package`). Inside the monorepo the workspace source export is
`@whiskeyjack/tauri`.*

## Install

```bash
npm install @whiskeyjack-net/tauri
```

Peers: `react`/`react-dom` 18+, `@tauri-apps/api` 2+, `react-i18next`. Everything
is inert (guarded) off Tauri, so it is safe to ship in a plain web/PWA build.

## Exports

- **Guards** — `isTauri()`, `isMobileTauri()` (iPad-aware), `isDesktopTauri()`,
  `isMacDesktop()`. The desktop shell must gate on **desktop** (mobile Tauri
  also sets `__TAURI_INTERNALS__`), or its desktop-only CSS leaks onto phones.
- **`WindowControlsLeft` / `WindowControlsRight`** — CSD window-control buttons,
  rendering the exact per-side buttons the backend reports (`data-wc-left` /
  `data-wc-right` on `<html>`), so the app matches each desktop's convention.
  Mount them in the DS `AppHeader`'s `chrome` slot.
- **`useSystemAccent()`** — on Tauri desktop, reads the OS accent color and
  overrides the DS `--color-accent-*` variables, adds the `.tauri-desktop` /
  `.tauri-platform-*` markers, and publishes the `--wc-left/right-px`
  window-control footprint the header-clearance CSS consumes. No-op elsewhere.
- **`@whiskeyjack-net/tauri/css/window-controls`** — the window-control CSS
  (import once); pairs with the components and the `AppHeader`
  `chrome`/`rowClassName` extension points.

## Not included (by design)

- The **Rust** side (`src-tauri/`: the `get_system_accent_color` /
  `get_window_controls_layout` commands, tray/menus, notifications) is an
  **owned scaffold template**, seeded from a reference app — not an npm library.
- The in-app **updater** and **auth/sync** are app-coupled (GitHub-release
  config, Firebase) and live in the app or a future starter kit.

## License

MIT
