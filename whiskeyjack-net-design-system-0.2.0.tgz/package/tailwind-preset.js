import plugin from 'tailwindcss/plugin'

/**
 * Whiskeyjack design-system Tailwind preset.
 *
 * Consume from an app's tailwind.config.js:
 *
 *   import preset from '@whiskeyjack/design-system/tailwind-preset'
 *   export default {
 *     presets: [preset],
 *     content: [...],   // content globs stay app-side
 *   }
 *
 * Every value maps to a CSS variable from the token build (variables.css must
 * be imported before any of these classes render). Because the colors are
 * plain var() strings, Tailwind cannot derive alpha – opacity modifiers like
 * `bg-error-500/50` are unsupported; use color-mix() in an arbitrary value
 * instead. The preset uses `theme.extend`, so Tailwind's default palette and
 * scales remain available alongside the token names.
 */

const scale = (family, steps) =>
  Object.fromEntries(steps.map((s) => [s, `var(--color-${family}-${s})`]))

const FULL = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900]

/** @type {Partial<import('tailwindcss').Config>} */
export default {
  future: { hoverOnlyWhenSupported: true },
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        neutral: scale('neutral', [...FULL, 950]),
        warm: scale('warm', FULL),
        // Runtime accent system: the app (or the OS integration) rewrites these
        // variables via applyAccentColor(); only the generated steps exist.
        accent: scale('accent', [50, 100, 400, 500, 600, 700]),
        // Semantic scales (byte-exact Tailwind v3 palette values in the tokens)
        success: scale('success', FULL),
        warning: scale('warning', [...FULL, 950]),
        error: scale('error', [...FULL, 950]),
        info: scale('info', FULL),
        orange: scale('orange', FULL),
        yellow: scale('yellow', FULL),
      },
      fontFamily: {
        sans: ['var(--font-family-sans)'],
        mono: ['var(--font-family-mono)'],
      },
      // Radius + shadow tokens currently mirror Tailwind's defaults exactly, so
      // mapping them is a no-op today – it exists so a future token change
      // propagates through utility classes without touching app configs.
      borderRadius: {
        sm: 'var(--radius-sm)',
        DEFAULT: 'var(--radius-base)',
        md: 'var(--radius-md)',
        lg: 'var(--radius-lg)',
        xl: 'var(--radius-xl)',
        '2xl': 'var(--radius-2xl)',
        '3xl': 'var(--radius-3xl)',
      },
      boxShadow: {
        sm: 'var(--shadow-sm)',
        DEFAULT: 'var(--shadow-base)',
        md: 'var(--shadow-md)',
        lg: 'var(--shadow-lg)',
        xl: 'var(--shadow-xl)',
        '2xl': 'var(--shadow-2xl)',
      },
    },
  },
  plugins: [
    // Layout gates for the side-by-side (sidebar) presentation. `wide` replaces
    // the plain lg: gate and `xlwide` the xl: gate wherever a class is tied to
    // the sidebar layout (the rail itself, hiding the TabBar, content max-width,
    // the main-pane alignment padding):
    // - fine pointer (desktop): unchanged, sidebar from 1024px / rail from 1280px.
    // - coarse pointer (tablets AND large phones): landscape only, from 768px --
    //   portrait tablets keep the tabbed layout (even the 13" iPads, whose
    //   1024px+ portrait width used to deploy the sidebar), and rotating a
    //   device to landscape deploys it. 768px matches the native rotation gate
    //   (phones with a >=768pt/dp long side may rotate at all).
    plugin(({ addVariant }) => {
      addVariant(
        'wide',
        '@media (min-width: 768px) and (pointer: coarse) and (orientation: landscape), (min-width: 1024px) and (pointer: fine)'
      )
      addVariant(
        'xlwide',
        '@media (min-width: 1280px) and (pointer: coarse) and (orientation: landscape), (min-width: 1280px) and (pointer: fine)'
      )
    }),
  ],
}
